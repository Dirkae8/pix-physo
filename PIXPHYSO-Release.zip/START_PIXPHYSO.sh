#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$DIR/PIXPHYSO.html"
elif command -v open >/dev/null 2>&1; then
  open "$DIR/PIXPHYSO.html"
else
  echo "Open $DIR/PIXPHYSO.html in any modern browser."
fi