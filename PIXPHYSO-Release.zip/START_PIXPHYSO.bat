@echo off
if exist "%~dp0PIXPHYSO.exe" (
  start "" "%~dp0PIXPHYSO.exe"
) else (
  echo PIXPHYSO.exe not found. Please use the full native release archive.
  pause
)